﻿using Volo.Abp.AspNetCore.Mvc.Authentication;

namespace Acme.BookStore.Web.Controllers;

public class AccountController : ChallengeAccountController
{

}
