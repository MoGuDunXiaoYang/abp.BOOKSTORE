$(function () {
    abp.log.debug('Index.js initialized!');
});