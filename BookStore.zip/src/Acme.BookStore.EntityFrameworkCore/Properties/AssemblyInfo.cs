﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("Acme.BookStore.EntityFrameworkCore.Tests")]
